import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:noid_app/data/repository/user_repo.dart';
import 'dart:async';
import 'validators.dart';
import 'package:rxdart/rxdart.dart';
part 'login_event.dart';
part 'login_state.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> with Validators {
  // * Email & Password Stream Controllers
  final _email = BehaviorSubject<String>();
  final _password = BehaviorSubject<String>();

  // * UserRepo instance
  final UserRepo userRepo = UserRepo();

  // * Email Stream Getter & Setter + Validator
  Stream<String> get email => _email.stream.transform(validateEmail);
  Function(String) get changeEmail => _email.sink.add;

  // * Password Stream Getter & Setter + Validator
  Stream<String> get password => _password.stream.transform(validatePassword);
  Function(String) get changePassword => _password.sink.add;

  // * Combined Email & Password Stream (For Validation)
  Stream<bool> get submitValid =>
      Rx.combineLatest2(email, password, (email, password) => true);

  void dispose() {
    _email.close();
    _password.close();
  }

  LoginBloc() : super(LoginInitial()) {
    on<LogOut>(((event, emit) => userRepo.logOut()));
    on<LoginRetry>(((event, emit) => emit(LoginInitial())));
    on<LoginSubmit>(((event, emit) async {
      emit(LoginLoading());
      // * Login Success Check
      bool loginSuccess = await submitLogin(_email, _password, userRepo);
      loginSuccess ? emit(LoginSuccess()) : emit(LoginFail());
    }));
  }
}

// * Login Submit Function
Future<bool> submitLogin(BehaviorSubject _email, BehaviorSubject _password,
    UserRepo userRepo) async {
  final validEmail = _email.value;
  final validPassword = _password.value;

  // * Wordpress API Login
  userRepo.loginUser(validEmail, validPassword);

  // * Login Response Bool
  var logResponse = await userRepo.isLoggedIn();
  return logResponse;
}
