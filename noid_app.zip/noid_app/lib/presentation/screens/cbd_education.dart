import 'package:flutter/material.dart';

class CBDEducation extends StatelessWidget {
  const CBDEducation({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Text('CBD Education');
  }
}
